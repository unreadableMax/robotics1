#include <iostream>
#include <Eigen/Core>
#include <Eigen/Dense>
#include <fstream>
#include <vector>
#include <string>
#include <rbdl/rbdl.h>
#include <rbdl/addons/luamodel/luamodel.h>

using namespace RigidBodyDynamics;
using namespace RigidBodyDynamics::Math;

using namespace Eigen;
const double g = 9.81;

// Define a few types to make it easier
typedef VectorXd (*rhsFuncPtr) (const double, const VectorXd&);
typedef VectorXd (*integratorFuncPtr) (const double, const VectorXd&, const double, rhsFuncPtr);

Model* pendulum(nullptr);

VectorXd heun_integrator (const double t, const VectorXd &y, const double h, rhsFuncPtr rhs) {
	return 0.5 * (rhs (t, y) + rhs (t + h, y + h * rhs(t, y)));
}
VectorXd rk4_integrator (const double t, const VectorXd &y, const double h, rhsFuncPtr rhs) {
	VectorXd k1 = rhs (t, y);
	VectorXd k2 = rhs (t + (double) 0.5 * h, y + (double) 0.5 * h * k1);
	VectorXd k3 = rhs (t + (double) 0.5 * h, y + (double) 0.5 * h * k2);
	VectorXd k4 = rhs (t + h, y + h * k3);

	return (double) 1. / 6. * (k1 + (double) 2. * k2 + (double) 2. * k3 + k4);
}

VectorXd euler_integrator (const double t, const VectorXd &y, const double h, rhsFuncPtr rhs) {
	return rhs (t, y);
}


VectorXd rhs (double t, const VectorXd &y) {
	assert (y.size() == 4);

	VectorNd res (VectorNd::Zero(4));
	VectorNd q (VectorNd::Zero(2));
	VectorNd qd (VectorNd::Zero(2));
	VectorNd qdd (VectorNd::Zero(2));
	VectorNd tau (VectorNd::Zero(2));

	res[0] = y[2];
	res[1] = y[3];

	q[0] = y[0];
	q[1] = y[1];

	qd[0] = y[2];
	qd[1] = y[3];

	assert(pendulum);
	ForwardDynamics(*pendulum, q,qd,tau,qdd);

	res[2] = qdd[0];
	res[3] = qdd[1];

	return res;
}


int main(int argc, char *argv[]) {

	//Initial values
	pendulum = new Model;

	if (! RigidBodyDynamics::Addons::LuaModelReadFromFile( "double_pendulum.lua" , pendulum, false)) {
		std::cerr << "Error loading model - aborting" << std::endl;
		abort();
	}

	assert(pendulum->dof_count == 2);

	VectorNd y0 (VectorNd::Zero(4));

	double t0 = 0.0;
	double tf = 20.0;
	double h = .001;
	
	y0[0] = M_PI*.5;
	y0[1] = 0.0;
	y0[2] = 0.0;
	y0[3] = 0.0;
	std::ofstream of("animation.csv");

	double t=t0;
	VectorNd y = y0;
	
	while (t <= tf) {
		y = y + h * rk4_integrator (t, y, h, rhs);
		of << t << ", " << y[0] << ", " << y[1] << "\n";
		t = t + h;
	}

	of.close();
	return 0;
}
