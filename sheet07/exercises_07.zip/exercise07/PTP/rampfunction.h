#ifndef RAMPFUNCTION_H
#define RAMPFUNCTION_H
class RampFunction {
public:
// s distance to travel, a accelleration, vmax maximal speed
RampFunction(double s, double a=2, double vmax=1);
~RampFunction();



double getEndTime();
double getT1();
double getT2();
double S(double t);


private:
double t_end;
double t1;
double t2;
double s;
double vmax;
double a;
};
#endif //RAMPFUNCTION_H
