#include <assert.h>
#include <iostream>
#include <cmath>

#include "rampfunction.h"

RampFunction::RampFunction(double s, double a, double vmax) :  t_end(0), t1(0), t2(0)  {
	this->s = s;
	this->a = a;
	this-> vmax = vmax;
	
	
	// Compute here, t1,t2 and t_end
	
	double sabs = std::abs(s);
	if ((vmax*vmax/a) > sabs) {
		// s is too short, will not reach vmax
		t_end=2.; // <<--
		t1=1.; // <<--
		t2=1.; // <<--
		
	} else {
		//reaching vmax;
		// will flat 
		t_end = 2.; // <<--
		t1 = 1.0; // <<--
		t2 = 1.0; // <<--
	}
	
	
	
}


double RampFunction::S(double t) {
	assert(t<=t_end);
	
	return s; // <<--
}


RampFunction::~RampFunction() {
}


double RampFunction::getEndTime() {
	return t_end;
}
double RampFunction::getT1() {
	return t1;
}
double RampFunction::getT2() {
	return t2;
}
