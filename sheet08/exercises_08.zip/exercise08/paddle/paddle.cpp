
#include "paddle.h"

using namespace Eigen;




Paddle::Paddle() : orientation( Eigen::Matrix3d::Identity()), position(0.,0.,0.){

}
Paddle::~Paddle() {

}

Eigen::Vector3d Paddle::getEulerAngles() {
	return orientation.transpose().eulerAngles(2, 0, 2); 
}

bool Paddle::canHitBall(Eigen::Vector3d pos, Eigen::Vector3d v) {

	
	return pos[2] < 0; //<- Replace this 
}

Eigen::Vector3d Paddle::reflect(Eigen::Vector3d v) {
			//Put your reflection matrix here
			Eigen::Matrix<double,3,3> refl;
			refl <<	1, 0, 0,
					0, 1, 0,
					0, 0, 1;

			return refl*v; //<- Replace this Adjust this line
}
