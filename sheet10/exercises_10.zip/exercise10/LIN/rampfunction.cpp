#include <assert.h>
#include <iostream>
#include <cmath>

#include "rampfunction.h"

RampFunction::RampFunction(double s, double a, double vmax) :  t_end(0), t1(0), t2(0)  {
	this->s = s;
	this->a = a;
	this-> vmax = vmax;
	
	
	// Compute here, t1,t2 and t_end
	
	double sabs = std::abs(s);
	if ((vmax*vmax/a) > sabs) {
		// s is too short, will not reach vmax
		t_end=2*std::sqrt(sabs/a);
		t1=t_end/2.;
		t2=t_end/2.;
		
	} else {
		//reaching vmax;
		// will flat 
		t1 = vmax/a;
		t_end = sabs/vmax + vmax/a;
		t2 = t_end - t1;
	}
	
	
	
}
RampFunction::~RampFunction() {

}


double RampFunction::getEndTime() {
	return t_end;
}
double RampFunction::getT1() {
	return t1;
}
double RampFunction::getT2() {
	return t2;
}

//~ double RampFunction::V(double t) {
	//~ assert(t<=t_end);
	//~ if (t < t1) {
		//~ return t*a;
	//~ } else if (t >= t2) {
		//~ return (t_end -t )*a;
	//~ } else {
		//~ return vmax;
	//~ }
//~ }

double RampFunction::S(double t) {
	assert(t<=t_end);
	
	if (t < t1) {
		return 0.5*t*t*a;
	} else if (t >= t2) {
		return s-0.5*(t_end -t )*(t_end -t )*a;
	} else {
		return 0.5*t1*t1*a + (t-t1)*vmax;
	}
}
