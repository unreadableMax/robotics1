#include <iostream>
#include <Eigen/Core>
#include <Eigen/Dense>
#include <Eigen/StdVector>
#include <fstream>
#include <vector>
#include <string>

#include "rampfunction.h"
#include "simpletests.h"

#include <rbdl/rbdl.h>
#ifndef RBDL_BUILD_ADDON_LUAMODEL
	#error "Error: RBDL addon LuaModel not enabled."
#endif
#include <rbdl/addons/luamodel/luamodel.h>
using namespace RigidBodyDynamics;
using namespace Eigen;


// Define a few types to make it easier
typedef Matrix<double, 6, 1>  Vector6d;

// Read why this has to be done here:
//  http://eigen.tuxfamily.org/dox/group__TopicStlContainers.html
typedef std::vector<Vector6d, Eigen::aligned_allocator<Vector6d> > Vector6dVector ;
typedef std::vector<Vector3d, Eigen::aligned_allocator<Vector3d> > Vector3dVector ;

struct datarow_t {
	double t;
	Vector6d q;
};

typedef std::vector<datarow_t> Data ;


/* Put your 2d coordinates to the drawing in here*/

Vector3dVector endPoints(
	{
		Vector3d(0,1,0),
		Vector3d(0,0,0),
		Vector3d(1,0,0),

	});

/* Transformation from the local to the global system */

class Transformation {
	private:
	double scale;
	Vector3d translate;
	Eigen::Matrix3d M;
	
	public:
	Transformation() {
		//Some default values
		scale =0.1;
		translate = Vector3d(0.5,0,0.0);
		//~ M = Eigen::AngleAxisd(0.5*M_PI, Vector3d::UnitY());
		M = Eigen::Matrix3d::Identity();
	}

	bool calibrate(Vector3d A,Vector3d B,Vector3d C) {
		Vector3d AB = B - A;
		Vector3d AC = C - A;
		Vector3d n = AB.cross(AC); //normal
		//Test, if the given values make sense
		if (AB.norm() <1E-10 || AC.norm() < 1E-10|| n.norm() < 1E-10)
			return false;
		//Put your code here and replace the fixed values
		scale = 1;
		translate = Vector3d(0,0,0);;
		Vector3d x = Vector3d(1,0,0);
		Vector3d z = Vector3d(0,0,1);
		Vector3d y = Vector3d(0,1,0);
		
		M <<	x[0], y[0], z[0], 
				x[1], y[1], z[1], 
				x[2], y[2], z[2];
		return true;
	}


	Vector3d transform(Vector3d in) {
		return M * in*scale + translate;
	}

	Matrix3d pointingMatrix() {
		Matrix3d Mz = Matrix3d::Identity() * Eigen::AngleAxisd(0.5*M_PI, Vector3d::UnitY());
		return   (M *  Mz).transpose();
	}
	
};

/* Make calling the inverse kinematics a little easier */
bool invKin(Model& model, Vector3d pos, Matrix3d ori, Vector6d& q) {
	int tcp_id = model.GetBodyId("TCP");
	InverseKinematicsConstraintSet cs;
	cs.AddPointConstraint (tcp_id,Vector3d(0,0,0), pos);
	cs.AddOrientationConstraint  (tcp_id, ori);

	// run Inverse Kinematic
	Eigen::VectorXd q_start = q;
	Eigen::VectorXd q_new;
	bool ret = InverseKinematics(model, q_start, cs, q_new);
	if (ret)
		q=q_new;
	return ret;
}

/* PTP Motion */
Vector6dVector PTP(Vector6d q_start, Vector6d q_end, double dt = 0.01, double a = 1, double vmax = 2.) {
	Vector6dVector l;
	
	Vector6d dq = q_end - q_start;
	double longest =0;
	for (int i =0; i < 6; i++) {
		longest = std::max(longest, std::abs(dq[i]));
	}
	if (longest <= 0){
		l.push_back(q_start);
		return l;
	}
	
	RampFunction rf(longest,a,vmax);
	double t_end = rf.getEndTime();
	for (double t=0; t < t_end; t+=dt) {
		Vector6d q = q_start + dq*(rf.S(t)/std::abs(longest));
		l.push_back(q);
		
	}
	
	return l;
}

/*LIN motion */
// Put your code in this function
Vector6dVector LIN(Model& model, Vector3d p_start, Vector3d p_end, Matrix3d ori,Vector6d q_start, double dt = 0.01, double a = .15, double vmax = .1) {
	
	Vector6dVector l;
	
	double t_end = 1.5;
	Vector6d q = q_start;
	for (double t=0; t < t_end; t+=dt) {
		//Linear interpolation without a ramp
		// Put your code in this function
		Vector3d pos = t/t_end*(p_end - p_start)+p_start;
			
		bool ret = invKin(model, pos, ori,q);
		if (!ret) {
			std::cout << "InverseKinematics did not find a solution" << std::endl;
		} else {
			l.push_back(q);
		}
	}
	
	return l;
}


void writeFile(std::string filename, Data& data) {
	std::ofstream outfile(filename.c_str());
	if (!outfile.good()) {
		std::cerr << "Could not open '" << filename << "'" << std::endl;
		
	}
	for (size_t i =0 ; i < data.size(); i++) {
		outfile << data[i].t ;
		for(int j=0; j < 6; j++) {
			outfile << ", " << data[i].q[j];
		}
		outfile << "\n";
	}
	
	outfile.close();
}

void appendMotion(const Vector6dVector& motion, Data& data, double& t, double dt) {
	for (std::size_t j = 0; j < motion.size(); ++j) {
		datarow_t dr;
		dr.t = t;
		t+=dt;
		dr.q = motion[j];
		data.push_back(dr);
	}
}


int main(int argc, char *argv[]) {

	
	Model model;
	if (!Addons::LuaModelReadFromFile ("kuka.lua", &model, false)) {
		std::cerr << "Error loading lua file" << std::endl;
		abort();
	}
	
	Data data;
	double t = 0.0;
	double dt = 0.01;
	Vector6d q_home;
	q_home << 0,-M_PI/2.,M_PI/2.,0,0,0;
	Vector6d q_start = q_home;

	Transformation tr;

	// Different calibrations to play with
	
	// assert(tr.calibrate(Vector3d(0.5,0,0),Vector3d(0.6,0.0,0),Vector3d(0.5,0.1,0)));
	// assert(tr.calibrate(Vector3d(0.7,0,.2),Vector3d(0.7,-0.1,.2),Vector3d(0.7,0.,0.3)));
	// assert(tr.calibrate(Vector3d(0.5,0,0.2),Vector3d(0.6,0.0,0.2),Vector3d(0.5,0.,0.3)));
	// assert(tr.calibrate(Vector3d(0.5,0,.2),Vector3d(0.6,0.0,.2),Vector3d(0.5,0.1,0.3)));
	
	Matrix3d ori = tr.pointingMatrix();

	assert(endPoints.size() > 0);

	


	//LIN Motion	
	for (size_t i=0; i < endPoints.size() - 1; i++) {
		Vector3d start = tr.transform(endPoints[i]);
		Vector3d end = tr.transform(endPoints[(i+1)]);
		Vector6dVector motion = LIN(model, start, end,ori, q_start, dt);
		appendMotion(motion,data,t,dt);
	}


	
	
		
	writeFile("animation.csv", data);
	
	return 0;
}
